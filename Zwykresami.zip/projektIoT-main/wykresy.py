import matplotlib.pyplot as plt
import pandas as pd
from tkinter import Tk, filedialog
import random

# Wybór plików Excel za pomocą okna dialogowego
Tk().withdraw()
filenames = filedialog.askopenfilenames(filetypes=[("Excel files", "*.xlsx")])

# Styl punktacji dla każdego pomiaru
marker_styles = ['o', 's', 'd', '^', 'v', '>', '<', 'p', 'P', '*', 'h']

# Iteracja po wybranych plikach
for filename in filenames:
    # Wczytanie danych z pliku Excel
    df = pd.read_excel(filename)

    # Sprawdzenie, czy kolumna "omega" jest obecna i pominięcie jej
    if 'omega' in df.columns:
        df = df.drop(columns=['omega'])

    # Utworzenie wykresu
    plt.figure(figsize=(10, 6))

    # Losowy wybór 10 wierszy
    random.seed()  # Resetowanie stanu losowego
    indices = random.sample(range(len(df)), 10)  # Losowanie 10 różnych indeksów
    df_sampled = df.iloc[indices]

    # Iteracja po wierszach
    for idx, (row, marker) in enumerate(zip(df_sampled.iterrows(), marker_styles)):
        # Wygenerowanie wykresu dla każdego wiersza z odpowiednim stylem punktacji
        label = f"{row[0]} - {row[1]['Freq']}"  # Nazwa w legendzie
        plt.plot(row[1][2:], marker=marker, linestyle='-', label=label)

    # Ustawienie wartości na osi x jako częstotliwości
    plt.xticks(ticks=range(len(df.columns[2:])), labels=df.columns[2:], rotation=45)

    # Sprawdzenie, czy nazwa pliku to 'wsp teta', aby ustawić odpowiednią skalę dla osi y
    if 'wsp teta' in filename:
        plt.yscale('linear')
    else:
        plt.yscale('log')

    plt.xscale('log')
    # Dodanie opisów osi oraz tytułu
    plt.xlabel('Frequency', fontsize=14)
    plt.ylabel('Value', fontsize=14)
    plt.title(f'Wykres dla pliku {filename.split("/")[-1]}', fontsize=16, color='red')

    # Dodanie legendy
    plt.legend()

    # Wyświetlenie wykresu
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.tight_layout()
    plt.show()
